// Задание 1: компонент Header возвращает название магазина в теге h1
function Header() {
  return <h1 className="header">Магазин «ТехноМир»</h1>
}

export default Header
