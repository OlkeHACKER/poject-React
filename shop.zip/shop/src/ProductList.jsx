import ProductCard from './ProductCard.jsx'

// Задание 3: каталог. Массив приходит через props, карточки строим через map.
function ProductList(props) {
  return (
    <div className="list">
      {props.products.map((product) => (
        <ProductCard
          key={product.id}
          title={product.title}
          price={product.price}
          inStock={product.inStock}
        />
      ))}
    </div>
  )
}

export default ProductList
