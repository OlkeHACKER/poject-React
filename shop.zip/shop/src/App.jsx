import Header from './Header.jsx'
import ProductList from './ProductList.jsx'

// Массив из пяти товаров: id, title, price, inStock
const products = [
  { id: 1, title: 'Ноутбук Lenovo IdeaPad', price: 289000, inStock: true },
  { id: 2, title: 'Смартфон Samsung Galaxy A55', price: 199000, inStock: true },
  { id: 3, title: 'Наушники Sony WH-1000XM5', price: 159000, inStock: false },
  { id: 4, title: 'Клавиатура Logitech MX Keys', price: 62000, inStock: true },
  { id: 5, title: 'Монитор Dell 27"', price: 134000, inStock: false },
]

function App() {
  // Со звёздочкой: сколько товаров в наличии
  const inStockCount = products.filter((p) => p.inStock).length

  return (
    <div className="app">
      <Header />
      <p className="summary">
        В наличии: {inStockCount} из {products.length}
      </p>
      <ProductList products={products} />
    </div>
  )
}

export default App
