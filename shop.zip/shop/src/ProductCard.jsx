// Задание 2: карточка товара. Все данные приходят снаружи через props.
function ProductCard(props) {
  return (
    <div className={props.inStock ? 'card' : 'card card--out'}>
      <h2>{props.title}</h2>
      <p className="price">Цена: {props.price} тг</p>
      <p className={props.inStock ? 'stock' : 'stock stock--out'}>
        {props.inStock ? 'В наличии' : 'Нет в наличии'}
      </p>
    </div>
  )
}

export default ProductCard
